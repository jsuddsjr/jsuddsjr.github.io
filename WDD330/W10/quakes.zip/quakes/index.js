import QuakesController from "./QuakesController.js";

const quakes = new QuakesController("#quakeList");
quakes.init();
